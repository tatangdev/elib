import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buku-pinjaman',
  templateUrl: './buku-pinjaman.page.html',
  styleUrls: ['./buku-pinjaman.page.scss'],
})
export class BukuPinjamanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
