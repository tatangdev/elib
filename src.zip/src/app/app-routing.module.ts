import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadChildren: './home/home.module#HomePageModule'
  },
  {
    path: 'list',
    loadChildren: './list/list.module#ListPageModule'
  },
  { path: 'profil', loadChildren: './profil/profil.module#ProfilPageModule' },
  { path: 'daftar-favorit', loadChildren: './daftar-favorit/daftar-favorit.module#DaftarFavoritPageModule' },
  { path: 'buku-pinjaman', loadChildren: './buku-pinjaman/buku-pinjaman.module#BukuPinjamanPageModule' },
  { path: 'detail', loadChildren: './detail/detail.module#DetailPageModule' }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
