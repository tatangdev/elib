import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BukuPinjamanPage } from './buku-pinjaman.page';

describe('BukuPinjamanPage', () => {
  let component: BukuPinjamanPage;
  let fixture: ComponentFixture<BukuPinjamanPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BukuPinjamanPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BukuPinjamanPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
