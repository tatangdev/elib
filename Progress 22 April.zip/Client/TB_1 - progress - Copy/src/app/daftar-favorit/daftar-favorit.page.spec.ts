import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DaftarFavoritPage } from './daftar-favorit.page';

describe('DaftarFavoritPage', () => {
  let component: DaftarFavoritPage;
  let fixture: ComponentFixture<DaftarFavoritPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DaftarFavoritPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DaftarFavoritPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
