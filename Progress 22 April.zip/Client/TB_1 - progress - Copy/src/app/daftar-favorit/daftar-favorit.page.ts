import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daftar-favorit',
  templateUrl: './daftar-favorit.page.html',
  styleUrls: ['./daftar-favorit.page.scss'],
})
export class DaftarFavoritPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
