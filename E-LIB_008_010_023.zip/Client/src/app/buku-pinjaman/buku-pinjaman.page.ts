import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { BookService } from '../book.service';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-buku-pinjaman',
  templateUrl: './buku-pinjaman.page.html',
  styleUrls: ['./buku-pinjaman.page.scss'],
})
export class BukuPinjamanPage implements OnInit {
  pinjaman: any;
  constructor(public router: Router, private bookService: BookService, private storage: Storage) { }

  ngOnInit() {
    this.bookService.getPinjaman().subscribe(async response => {
      const pin = await response.json();
      const data = await this.storage.get('isLoggedIn');
      const id = JSON.parse(data).id;
      this.pinjaman = pin.filter(val => {
        return val.user._id === id;
      });
      console.log(this.pinjaman);
    })
  }
  goHome(){
    this.router.navigate(['/home']);
  }
}
