import { Component, OnInit } from '@angular/core';
import { NavParams, ModalController } from '@ionic/angular';
import { BookService } from '../book.service';

@Component({
  selector: 'app-pinjam',
  templateUrl: './pinjam.page.html',
  styleUrls: ['./pinjam.page.scss'],
})
export class PinjamPage implements OnInit {
  tanggal_peminjaman: any;
  tanggal_pengembalian: any;
  data = {
    author: '',
    deskripsi: '',
    gambar: '',
    genre: '',
    kodebuku: '',
    lokasi: '',
    name: '',
  };
  constructor(private navParams: NavParams, private bookService: BookService, private modal: ModalController) { }

  ngOnInit() {
    this.data = this.navParams.data.data;
    this.tanggal_peminjaman = new Date();
    this.tanggal_pengembalian = new Date();
    this.tanggal_pengembalian.setDate(this.tanggal_peminjaman.getDate() + 7);
    
  }

  back() {
    this.modal.dismiss();
  }

  pinjamBuku() {
    this.bookService.pinjam(this.navParams.data.token, this.navParams.data.buku, this.tanggal_peminjaman, this.tanggal_pengembalian).subscribe(response => {
      console.log(response.json());
      this.modal.dismiss();
    });
  }

}
