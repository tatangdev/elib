import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  username: any;
  password: any;

  constructor(public router: Router, public authService: AuthService, public storage: Storage) { }

  ngOnInit() {
  }

  goHome() {
    // this.router.navigate(['/home']);
  }

  onSubmit() {
    this.authService.login(this.username, this.password).subscribe(async response => {
      let dataUser = response.json();
      if (dataUser.token) {
        await this.storage.set('isLoggedIn', JSON.stringify(dataUser)).then(() => {
          this.router.navigate(['/home']);
        });
      }
    });
  }
}
