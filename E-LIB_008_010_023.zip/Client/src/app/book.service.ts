import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(public http: Http) { }
  loadBook() {
    return this.http.get('https://elib-server.herokuapp.com/api/book');
  }

  pinjam(token, buku, tanggalPeminjaman, tanggalPengembalian) {
    return this.http.post('https://elib-server.herokuapp.com/api/pinjaman', {
      tanggalPeminjaman,
      tanggalPengembalian,
      buku
    }, {
        headers: new Headers({
          Authorization: token
        })
      })
  }

  getPinjaman() {
    return this.http.get('https://elib-server.herokuapp.com/api/pinjaman');
  }
}
