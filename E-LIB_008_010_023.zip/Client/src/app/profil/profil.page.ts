import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-profil',
  templateUrl: './profil.page.html',
  styleUrls: ['./profil.page.scss'],
})
export class ProfilPage implements OnInit {
  user = {
    name: '',
    username: ''
  };

  constructor(public router: Router, private storage: Storage) { }

  async ngOnInit() {
    const user = await this.storage.get('isLoggedIn');
    console.log(JSON.parse(user));
    this.user = JSON.parse(user);
  }
  goHome() {
    this.router.navigate(['/home']);
  }
}
