import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book.service';
import { Response } from '@angular/http';
import { Storage } from '@ionic/storage';
import { AuthService } from '../auth.service';
import { PinjamPage } from '../pinjam/pinjam.page';
import { ModalController } from '@ionic/angular';



@Component({
  selector: 'app-list-buku',
  templateUrl: './list-buku.page.html',
  styleUrls: ['./list-buku.page.scss'],
})
export class ListBukuPage implements OnInit {
  bookList: any;
  constructor(public router: Router, public bookService: BookService, private storage: Storage, private authService: AuthService, private modalController: ModalController) {
    this.loadBook();
  }
  loadBook() {
    this.bookService.loadBook().subscribe((response: Response) => {
      let data = response.json();
      this.bookList = data;
      console.log(this.bookList);
    });
  }

  ngOnInit() {
  }
  goHome() {
    this.router.navigate(['/home']);
  }

  async pinjam(buku, databuku) {
    const data = await this.storage.get('isLoggedIn');
    const token = JSON.parse(data).token;
    this.presentModal(token, buku, databuku);
  }

  async presentModal(token, buku, data) {
    const modal = await this.modalController.create({
      component: PinjamPage,
      componentProps: {
        token,
        buku,
        data
      }
    });
    return await modal.present();
  }
}
